#Import

import math

#Fonction

def distanceEuclidiennePoints(EntierXa, EntierYa, EntierXb, EntierYb):
    return float(math.sqrt((EntierXa - EntierXb)**2 + (EntierYa - EntierYb)**2))

def distanceEuclidienneListe (liste1, liste2):
    return float(math.sqrt((liste1[0] - liste2[0])**2 + (liste1[1] - liste2[1])**2))

def distanceEntrePoint (cible1,cible2):
    return  float(math.dist([cible1.x,cible1.y],[cible2.x,cible2.y]))

