#Fonction

def creerFile ():#Crée la files
    return []

def estVide(file): #Booléen
    #Prend en paramètre une file et vérifie si elle est vide 
    return len(file)==0 #Renvoi True si file est vide

def enfiler (val,file): #files
    #Prend la file et la valeur pour la mettre dedans
    return file.append(val) #retourne la fille avec la valeur dedans

def defiler (file): #files
    #Défile le dernier élément
    if not(estVide(file)): #Vérificaton que la pile n'est pas vide
        return file.pop() #Supression de la première valeur de la pile