#Fonction

def creerPile ():#Crée la pile
    return []

def estVide (p): #Booléen
    #Prend en paramètre une pile et vérifie si elle est vide 
    if not p: #Vérification pour que la liste est vide
        return True #Vide
    else : 
        return False #Pas vide

def empiler(p,val): #Void (procédure)
    #Prend la pile vide et la valeur pour la mettre dedans
    p.append(val) #Ajout de la valeur

    return p 

def depiler(p): #Element
    #Dépile le dernier élément
    if not (estVide(p)): #Vérificaton que la pile n'est pas vide
        return p.pop() #Supression de la derniere valeur de la pile


def modifSommet(pi1,pi2):
    #Prend la première valeur de la pile 1 pour la mêtre dans la pile 2
    return empiler(depiler(pi1),pi2)

def inverse(pi1,pi2):
    #
    pi3 = creerPile()
    empiler(depiler(pi1),pi2)
    while not estVide(pi1) :
        empiler(depiler(pi2),pi3)
    return pi1