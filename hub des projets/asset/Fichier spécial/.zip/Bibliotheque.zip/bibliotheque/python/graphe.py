#Info

def estFeuille(self):
    if self.gauche == None and self.droite == None:
        return True
    else:
        return False


def hauteur(self):

    if self.gauche is None:
        fg = 0
    else:
        fg = self.gauche.hauteur()

    if self.droite is None:
        fd = 0
    else:
        fd = self.droite.hauteur()

    return 1+max(fg,fd)


def taille(self):

    if self.gauche is None:
        fg = 0
    else:
        fg = self.gauche.taille()

    if self.droite is None:
        fd = 0
    else:
        fd = self.droite.taille()

    return 1 + fg + fd

#Parcours

def parcoursPrefixe(self):
    if self.gauche is None : 
        fg = "" 
    else: 
        fg = self.gauche.parcoursPrefixe()
    if self.droite is None : 
        fd = "" 
    else: 
        fd = self.droite.parcoursPrefixe()
    return str(self.clef) + " " + fg + " " + fd

#parcours infixe : shg,racine,shd

def parcoursInfixe(self):
    if self.gauche is None : 
        fg = "" 
    else: 
        fg = self.gauche.parcoursInfixe()
    if self.droite is None : 
        fd = "" 
    else: 
        fd = self.droite.parcoursInfixe()
    return fg + " " + str(self.clef) + " " + fd

def parcoursPostfixe(self):
    if self.gauche is None : 
        fg = "" 
    else: 
        fg = self.gauche.parcoursPostfixe()
    if self.droite is None : 
        fd = "" 
    else: 
        fd = self.droite.parcoursPostfixe()
    return fg + " " + fd + " " + str(self.clef)

#Insertion dans un arbre
def insertAbr(self, clef):
    if clef < self.clef:#Si la clef a ajouter est plus petites que la racine
        if self.gauche is None:#Si le parent ne possède pas de fils
                self.gauche = Noeud(clef)#Ajout du noeud 
        else:#Si le parent possède deja une feuille
            self.gauche.insertAbr(clef)#Redémarage au fils
    elif clef > self.clef:#Si la clef a rajouter est plus grande
        if self.droite is None:#Si le parent ne possède pas de fils
            self.droite = Noeud(clef)#Ajout de la clef a droite 
        else:#Si le parent possède deja une feuille
            self.droite.insertAbr(clef)#Redémarage au fils

#Fonction recherche

def mini(self):

    if self.gauche == None:
        return print(self.clef)
    else:
        self.gauche.mini()


def maxi(self):

    if self.droite == None:
        return print(self.clef)
    else:
        self.droite.maxi()

def recherche(self, valeur):
    if self.clef == valeur:
        return print(True)
    elif self.clef > valeur:
        if self.gauche != None:
            self.gauche.recherche(valeur)
        else:
            return print(False)
    else :
        if self.droite != None:
            self.droite.recherche(valeur)
        else:
            return print(False)

#Parcours

def bfs(graph, sommet):
    visiter = []  # Ensemble pour stocker les sommets visités
    queue = []  # File pour stocker les sommets à visiter
    queue.append(sommet)  # Ajouter le sommet de départ à la file
    visiter.append(sommet)  # Marquer le sommet de départ comme visité

    while queue:
        sortie = queue.pop(0) #  Retire le premier sommet de la file

        for voisin in graph[sortie]:
            if voisin not in visiter:
                visiter.append(voisin)  # Marque le voisin comme visité
                queue.append(voisin)  # Ajoute le voisin à la file

        # Afichage de la visite :2 option possible
        
        #print (sortie)
    
    return print(visiter)

def dfs(graph, sommet):

    visiter = [] # Ensemble pour stocker les sommets visités
    queue = [] # File pour stocker les sommets à visiter
    queue.append(sommet) # Ajouter le sommet de départ à la file

    while queue:

        sortie = queue.pop(0) #  Retire le premier sommet de la file

        if sortie not in visiter:
            visiter.append(sortie) # Marque le voisin comme visité
            nonVisiter = [n for n in graph[sortie] if n not in visiter] #Vérification des voisins
            queue.extend(nonVisiter) # Ajout les voisins à la file

    return print(visiter)


