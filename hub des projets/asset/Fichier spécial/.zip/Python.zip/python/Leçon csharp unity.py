print ("Leçon Csharp Unity")
print ()

print ("1 : LES VARIABLES")
print ("-----------------")
print ()

print ("Les variables principles sont les mêmes que pour python. Mais il en existe une centaine d'autres")
print ()

print ("Pour les écrire en csharp, il faut faire comme ça :")
print ()

print ("""
public int leNom = 9;
public float leNom = 7.586f;
public bool leNom = true;
public string leNom = "Je suis bougie";
""")
print ()

print ("Le domaine public est accésible partout. Tandis que private non. ")
print ()

print ("En csharp unity, une variable est beaucoup utiliser, c'est GameObject. Pour l'écrire c'est comme ça :")
print ()

print ("""
public GameObject leNom;
""")
print ()

print ("Elle permet de stocker un objet de la scène /jeu. On peut en faire ce que l'on veut")
print ()

print ("Exemple connue")
print ()

print ("---------------------")
print ("Exemple 1: Minecraft.")
print ("---------------------")
print ()

print ("La quantité d'objet dans la barre d'inventaire")
print ()

print ("Pour les object, il n'y a que des variable int. On ne peut pas avoir des variables float. Par exemple, 27,5 blocs")
print ()

print ("La barre d'expérience")
print ()

print ("La barre d'expérience est représenté grace a une variable float selon les wiki. En gagnant de l'xp, le joueur ne gagne jamais d'un coup 1 niveau avec une bulle d'xp. Seulement 0.7 pour le fer ou 0.15 pour le bois")
print ()

print ("Le nombre affiché par le chiffre au dessus de la barre d'expérience est par contre représenté en int")
print ()

print ("----------------------------")
print ("Exemple 2 : League Of Legend")
print ("----------------------------")
print ()

print ("Les stats")
print ()

print ("Les stats sont afficher par des variables int et float. En jouant, ces variables seront modifier")
print ()

print ("Les noms des perssonages")
print ()

print ("Les noms des personnages sont en variables string. Elle peuvent contenir tout et n'importe quoi")
print ()

print ("Ouverture/ Fermeture du magasin")
print ()

print ("Le magasin s'ouvre et se ferme en pressant une touche. C'est représenté par une valeur booléene avec true pour la boutique ouverte et false pour la fenetre fermé")
print ()

print ("Exemple de programme")
print ()

print ("""
public bool isDoorOpen;

Porte ouverte = true
Porte fermé = false
""")
print ()

print ("-----------------------")
print ("Exemple 3 : Hearthstone")
print ("-----------------------")
print ()

print ("Dans ce jeu, il y a beaucoup de variable. De tout les type")
print ()

print ("2 : LES FONCTIONS")
print ()

print ("Les fonctions permettent de faire beaucoup d'action dans un jeu et sont combinable avec les variables")
print ()

print ("Les variables sont assemblé comme cela : type, nom, paramètre (optionnel)")
print ()

print ("Exemple de fonction classique :")
print ()

print ("""
void maFonction(int monInt)
""")

print ("1. La fonction Start")
print ()

print ("Cette fonction se lance au démarage. ")
print ()

print ("Exemple")
print ()

print ("""
public class test : ElKadiri {

    int monInt = 5;

    void start () {
        print (monInt); #Surtout utiliser pour les test / débeugage de script 
    }
}
""")
print ()

print ("Ce code ci-dessus va affiché la variable monInt au démarage de lecture. Cela retourne 5")
print ()

print ("Modifions le programmes")
print ()

print ("""
public class test : ElKadiri {

    int monInt = 5;

    void start () {
        print (monInt); 
        monInt++;           #Ajoute 1 a monInt = 5 ---> 1 et 1 seulement
        print (monInt);
        monInt += 1;²       #Ajoute 1 a monInt = 6 ---> le nombre que l'on souhaite
        print (monInt)

    }
}
""")
print ()

print ("Ces deux lignes font la même chose. Soit ajouter 1 dans monInt")
print ()

print ("2. La fonction update")
print ()

print ("Cette fonction est lu a chaque frame. Elle est lu tout le temps")
print ()

print ("Imaginons que nous partons sur le même principe que le script précédent. Voici le script avec update")
print ()

print ("""
public class test : ElKadiri {

    int monInt = 5;

    void Update () {
        print (monInt); 
    }
}
""")
print ()

print ("Une fois le code commencé, la console unity est spammé. Il faut allé dans colaps qui va affiché la variable + le nombre de fois que la frame est retourner")
print ()

print ("3. D'autres fonctions importantes")
print ()

print ("""
Awake() = appelée avant Start (). Elle permet de choisir l'ordre d'initialisation des scripts.
LateUpdate() = appelée après chaque Update(). Utile pour choisir l'ordre d'exécution du script (infini comme Update())
FixedUpdate() = à utiliser a la place de Update () pour une utilisation importante de rigidbody.
""")

print ("4. Une fonction qui ne doit plus ètre utiliser")
print ()

print ("""
void ONGUI()
""")
print ()

print ("Cette fonction permettait d'affiché des élément a l'écrant. Utiliser les UI")
print ()

print ("5. Pour créé ça propre fonction : ")
print ()

print ("Celle ci-dessous va faire des calcul")
print ()

print ("""
public class test : ElKadiri {
    
    int nombre1 = 5;
    int nombre2 = 7;
    
    void maFonction () {
        print ("Mon premier nombre est " + nombre1);
        print ("Mon second nombre est "+ nombre2);
        print ("Le résultat de l'adition est " + (nombre1 + nombre2));
    }

}
""")

print ("Cette fonction ne s'affichera pas car pas appelé . Réparons ça")
print ()

print ("""
public class test : ElKadiri {
    
    int nombre1 = 5;
    int nombre2 = 7;

    private Start (); 
    {
        maFonction ();
    }
    

    void maFonction () {
        print ("Mon premier nombre est " + nombre1);
        print ("Mon second nombre est "+ nombre2);
        print ("Le résultat de l'adition est " + (nombre1 + nombre2));
    }

}
""")
print ()

print ("Cette fonction s'affiche")
print ()

print ("6. Les paramètres")
print ()

print ("Prenons la foncxtions au dessus et rajoutons des paramètres. C'est comme pour python a quelque chose près")
print ()

print ("""
public class test : ElKadiri {
    
    int nombre1 = 5;
    int nombre2 = 7;

    private Start (); 
    {
        maFonction (8,12);
    }
    

    void maFonction (int parametre1, int parametre2) {
        print ("Mon premier nombre est " + parametre1);
        print ("Mon second nombre est "+ parametre2);
        print ("Le résultat de l'adition est " + (parametre1 + parametre2));
    }

}
""")
print ()

print ("parametre 1 et 2 sont les parametres. 8 et 12 sont les variables associé. Int car int spécifier. Appelable autant de fois que nécéssaire avec des paramètre différent")
print ()

print ("7. Exemple")
print ()

print ("Ce sont des vidéo : https://www.youtube.com/watch?v=MXD_dljMIVY&list=PLUWxWDlz8PYLKlr6F_fwCs02DH1g2hrgS&index=2 a 9,20")
print ()

print ("DISCLAMER: Start() et Update() sont spécifique a Unity. Pas le même nom ailleurs")
print ()

print ("3 : LES CONDITIONS")
print ()


