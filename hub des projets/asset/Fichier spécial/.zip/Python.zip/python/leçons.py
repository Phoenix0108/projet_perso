#coding:utf-8

"""
pour lancer l'interpréteur python, tapez python.
Pour le quiter, tapez quit()

"""
print("partie 1:commande pour le texte,le saut a la ligne,\n \t     la tabulation et les comentaire")

# commande pour afficher du Texte

print("My name is jeff")
print("And i want die")

# type de commentaire 

# commentaire d'une seule ligne

"""
commentaire de plusieurs lignes 
voici la preuve

"""

# saut a la ligne:

print("L'envers \ndu décor")
#ou
print("L'envers \n du décor")

#tabulation

print("\t l'envers du décor")

print("partie 2:stockage des données")

"""
Nommer une variable : doit commencer par une lettre
					  Ne pas contenir de caractère spéciaux
					  Ne pas contenir d'espaces
					  utiliser des underscores(_)
					  La variable doit commenté le code
"""

print("exemple")

"""
agePersonne =sintaxe la plus recommandé en informatique
ou
age_personne
ou
Age_Personne
ou
agepersonne
"""

print("une fois la sintaxe choisie, IL NE FAUT PAS CHANGER EN COURS DE ROUTE pour s'y retrouver ")

# affectation d'une donnée a une variable

print("Types de donnée")

"""
Type de donnée standard: entier numérique (int)
                         nombre flottant (float)
                         chaîne de caractère (str ou string)
                         booléen (bool)
                         autres (listes, disctonnaires etc)
"""
print("exemple")

agePersonne = 14 #nombre numérique (int)
agePersonne2 = "25" #chaine de caractère (str)
prixTtc = 40.52 #nombre flottant (float)
continuerRecette = True # booléen (bool) Peut ètre remplacer par Fals

#commande pour que le programme détecte le type de donnée

#print(type(_))

print("exemple")

print(type(agePersonne))
print(type(agePersonne2))
print(type(prixTtc))
print(type(continuerRecette))

# exécuté le programme avec la commande python leçons.py mais avant tapez cd desktop sinon il e trouvera pas le fichier

"""
Afichage de la valeur choisi:
commande = print(_)
"""

print("exemple")

print(agePersonne)

""" 
Pour inséré un texte avec la variable il faut faire la, commande ci dessous:
					print("Âge de la personne", agePersonne)
"""

print("exemple")

print("Prix TTC", prixTtc)

#exécuter le programe 

print("La fonction format")

texte = "L'age de la personne est {} et le prix TTC est de {} euros."
print(texte.format(agePersonne, prixTtc))

"""
Méthode plus rapide mais moin lisible
"""

print("L'age de la personne est {} et le prix TTC est de {} euros.".format(agePersonne, prixTtc))

""" 
Cette méthode fonctionne a tout les coups
"""

print("La saisie d'information sans saisir l'information dans le programme")

"""
Il existe une fonction pour cela
Elle ce nomme input A utilisé dans print()
"""

nomJoueur = input("Choisissez votre nom:")

print("bienvenue,", nomJoueur)

"""
Rapel des fonctions vue: print()    -> Afichage du texte brut
                         input()    ->lire la donnée saisie au clavier
                         type()     ->retourne le type de donnée, variable etc.
                         int(), float(), str() ->"caster" une donnée, la convertir
                         str.format -> formater une chaîne de caractère
"""

"""
print("exemple")

prixHT = input("Entrez un de prix HT: ")

prixTTC2 = prixHT + (prixHT * 20 / 100)

print("Prix TTC =", prixTTC2)
"""

print("ce programme ne fonctionne pas car le programme tente de calculer un caractère a un nombre entier")

print("résolution de problemme")

prixHT = input( "Entrez un prix HT:" )

prixHT = int(prixHT)

prixTTC2 = prixHT + (prixHT * 20 / 100)

print("Prix TTC =", prixTTC2)

print("exemple pour le booléen")

valeurBooleen = True

#Le programme affichera True

valeurBooleen = int(valeurBooleen)

print("valeurs=", valeurBooleen)

print("partie 3:opérateur et opération")

"""
Opérateur utilisée en programation: + (addition)
                                    - (soustraction)
                                    / (division)
                                    * (multiplication)
                                    % (modulo) -> reste d'une division euclidienne
"""

""" 
Pour les divisions, toujour faire un cast pour ètre sur de la précision
 du résultat

"""

print("Exemple")

calcul = 5 /2 
calcul = float(calcul)

print("Résultat =", calcul)

"""
Le reste de la division est le modulo

"""

print("Exemple")

calcul2 = 6 / 5
calcul2 = float(calcul2)

calcul3 = 9 % 2
calcul3 = int(calcul3)

print("résultat=", calcul2, "reste=",calcul3)

"""
Paire ou impaire ?
"""
nombre = 18 % 2

print("Ne pas sous estimer le modulo")

""" 
La multiplication, la division et le modulo sont prioritaire a la soustraction et a l'adition
Pour calculer une addition avant une multiplication, il faut des parantèse 

"""

print("exemple de programe dinamique")

niveauPerssonage = input( " Niveau de départ ? " )
niveauPerssonage = int(niveauPerssonage)

print("Niveau du perssonage:", niveauPerssonage)
print("Félicitaion, tu gagne un niveau ")

niveauPerssonage = niveauPerssonage + 1

print("Niveau du perssonage :", niveauPerssonage)

"""
Pour racourcir le code, on peut faire:

variable += X

variable -= X

variable *=X

variable /=X

Ceci sont des oppérateur d'affectation
"""

niveauPerssonage +=1

print("Félicitaion, tu gagne un niveau ")

print("Niveau du perssonage :", niveauPerssonage)

print("Partie 4: Structure conditionel")

print("création d'interface de mot de passe")

identifiant = "00"
mot_de_passe = "11"

print("interface de connexion")

user_id = input("entrer votre identifiant: ")

user_password = input(" entrer votre mot de passe: ")


if user_password == mot_de_passe:
	    		print("bienvenue", user_id)

"""
Opérateur de comparaison utilisé: == (égal a)
								  != (différent de )
								  <  (plus petit que)
								  >  (plus grand que)
								  <= (plus petit ou égal a)
								  >= (plus grand ou égal a )
Mot clef de condition           : if / elif / else

Condition multiple:				: and (et)
								  or (ou)
								  in / not in (dans / pas dans)							  
"""		

print("Exemple")

print("")

identifiant2 = "You"
mot_de_passe2 = "0202"

print("interface de connexion")

user_id = input("identifiant: ")
user_password = input("mot de passe ")

if user_id == identifiant2 and user_password == mot_de_passe2:
	print("vous ête connecté ")

print("exemple pour in ")

lettre_hasard = input("entre une lettre: ")

if lettre_hasard in "aeiouy":
	print("c'est une voyelle")
else:
	print("c'est une cosone")
lettre_hasard2 = input("entre une lettre: ")

if lettre_hasard2 not in "aeiouy": 
	print("c'est une consone")
else: 
	print("c'est une voyelle")
	
print("exemple elif")

age = input("ton age: ")

age = int(age)

if age == 18:
	print("Tu est majeur")
elif age <=17:
	print("tu est un ado") 
elif age <=10:
	print("tu est un enfant")
elif age <= 100:
	print("tu est un adulte ou une perssone agée")
else:
	print("tu as", age ,"ans")

	
age = input("Quel age a tu ?")
age = int(age)

"""
age > 0 ET age <= 100 --> 0 < age <= 100 

"""

if 0 < age <= 100:
	print("valide")

else:
	print("incorect réésayer")

print("")

print("Partie 5: boucle ")

"""
exemple sans boucle
"""

print("je suis une phrase")

"""
pour répété il faut copier coller A NE SURTOUT PAS FAIRE
"""

print("Pour créé une boucle on utilise la commande while")

print("Exemple")

i = 0
"""
i = compteur 
"""

while i <5:
	print("Je suis une phrase")
	i += 1

"""
Sans la ligne i += 1 la boucle serai infini et ferai planter l'ordinateur 
on peut l'arrèté avec controle + c 
"""
print ("")

print("Exemple de terminale minimaliste")

jeu_lance = True

while jeu_lance:
	#Fait des instruction en raport avec le jeu a ll'infinie
	choixMenu = input("> ")

	if choixMenu == "again":
		continue #La boucle continue

	elif choixMenu == "quit":
		break # Cette commande sert a sortir de la boucle

	elif choixMenu == "Hello":
		print("bonjour :-) !")

	elif choixMenu == "space":
		print("")

	else:
		print("commande introuvable")


print("A bientôt...")

"""
Boucle : while / for
mots-clés : break (casse la boucle) / continue (continue la boucle)
"""

print("Exemple pour for")

sentence = "bonjour tout le monde !"

for letter in sentence:
	print(letter)

print("A bientôt...")

