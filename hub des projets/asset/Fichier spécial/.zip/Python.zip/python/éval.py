#coding=utf-8

print("Ceci est un test de connaissance en python")

print("")

print("l'objéctif est d'afficher la classe de certaine donnée, de faire la tabulation et de créé une boucle")

print("")

print("bonne channce")

tempsPerdue = 20
tempsPerdue2 = "30"
tempsPerdue3 = 3.22
tempsPerdue4 = False

print("")

print("Exercice 1: afficher la classe de ses donnée")

print(type(tempsPerdue))

print("")

print(type(tempsPerdue2))

print("")

print(type(tempsPerdue3))

print("")

print(type(tempsPerdue4))

print("Exercice 2: Créé une boucle a partir de la donnée suivante ")

état_jeu = True

print("")

while état_jeu:
	choix_Menu = input(">")

	if choix_Menu == "Hi":
		print("Hello how are you today?")

	elif choix_Menu == "0":
		print("Why 0 ?")

	elif choix_Menu == "pomme de terre":
		print("Humm big fish and chips")

	elif choix_Menu == "game":
		print("Minecraft or Fortnite")

	elif choix_Menu == "Minecraft":
		print("Oh good choise")

	elif choix_Menu == "fortnite":
		print(" Seriously")

	elif choix_Menu == "quit":
		break

	elif choix_Menu == "quit2":
		état_jeu = False
		
	else:
		print("invalid command")

print("")

print("Good by")

print("Ceci est la fin du programme.")
