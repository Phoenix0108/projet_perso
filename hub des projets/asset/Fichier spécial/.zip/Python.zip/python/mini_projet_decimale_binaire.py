# -*- coding: utf-8 -*-
"""
 Created on Sat Oct 23 17:51:13 2021

 @author: Théo Mancini

 Modifier sur Visual Studio Code le 26/10/2021

 Par : Yanis El Kadiri
"""
print () 

print ("--------------------")
print () 

k = int(input("Choisissez un nombre entier positif --> ")) # Modifier
print () 

def decimale_binaire(n = k):
    assert ( int(n) and (n > 0) ) 

    j = n  # Affichage du nombre de départ (Modifier)
    l=""
    while n != 0:
        l=str(n%2)+l
        n=n//2
    return print("Pour {} la valeur en binaire est égal a {}".format(j, l)) # Modifier (de base = return l)

# A partir d'ici full modifier ou créé

g = decimale_binaire(k)
print () 

print ("- Vérification avec la formule 'bin()'")
print ()

def decimalBinaire (n = k) :
    j = n  # Affichage du nombre de départ
    return print("Pour {} la valeur binaire est égal a".format(j), int( bin (n) [2:]))

h = decimalBinaire (k)
print ()

if g == h : # Confirmation de la vérification 
    print ("Les deux valeurs binaires sont identiques. Le programme de base marche donc pour {}.". format (k))
else : 
    print ("Les deux valeurs binaires sont différentes. Il y a un problême quelque part")

print ()

print ("--------------------")
print ()